class CfgPatches
{
	class DCOGPT
	{
		// Meta information for editor
		name = "SFSM-Modules";
		author = "DCO Team";

		requiredVersion = 1.60;
		requiredAddons[] = {};
		units[] = {};
		weapons[] = {};
	};
};