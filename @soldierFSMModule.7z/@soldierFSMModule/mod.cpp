 name 			= "SFSM-Modules"; // Name of your mod
 author 		= "Tally (code) DCO (financing and design)."; // Affects Arma 3 Launcher, when the mod are loaded as local
 logo 			= "SFSM.paa"; // Logo displayed in the main menu
 logoOver 		= "SFSM.paa"; // When the mouse is over, in the main menu
 tooltip 		= "SFSM-Modules";
 tooltipOwned 	= "SFSM-Modules"; // Tool tip displayed when the mouse is left over, in the main menu
 picture 		= "SFSM.jpg"; // Picture displayed from the expansions menu. Optimal size is 2048x1024
 actionName 	= "";
 action 		= ""; // Website URL, that can be accessed from the expansions menu
 overview 		= "Modules for DCO Soldier FSM"; // Supports structured text
 hideName 		= 0; // Hide the extension name
 hidePicture	= 0;	// Hide the extension menu 
 dlcColor[] 	= {0.23,0.39,0.30,1}; // Color used for DLC stripes and backgrounds (RGBA)
 logoSmall 		= "SFSM.paa"; // Display in creative lists, next to the entities added by the mod
 